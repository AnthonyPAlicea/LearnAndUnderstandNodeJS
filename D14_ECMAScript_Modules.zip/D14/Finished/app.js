import greet from './greet.js';
import { greet as greet2 } from './greet2.js';

greet();
greet2();