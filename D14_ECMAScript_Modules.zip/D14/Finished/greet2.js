export const greet = function() {
	console.log('Hi');
}