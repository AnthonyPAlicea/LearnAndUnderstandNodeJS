export default function greet() {
	console.log('Hello');
}