import { MongoClient } from 'mongodb';
import dotenv from 'dotenv';

dotenv.config();

const uri = process.env.MONGODB_URI;

const client = new MongoClient(uri);

class Movie {
    constructor(movieData) {
      Object.assign(this, movieData);
    }
  
    getIMDBUrl() {
      return `https://www.imdb.com/title/${this.imdb.id}`;
    }
}

async function run() {
	try {
	  
	  // Get the database and collection on which to run the operation
	  const database = client.db("sample_mflix");
	  const movies = database.collection("movies");
  
	  // Query for a movie that has the title 'The Room'
	  const query = { title: "The Room" };
  
	  const options = {
		// Sort matched documents in descending order by rating
		sort: { "imdb.rating": -1 },
		// Include only the `title` and `imdb` fields in the returned document
		projection: { _id: 0, title: 1, imdb: 1 },
	  };
  
	  // Execute query
	  const movie = await movies.findOne(query, options);

	  const customMovie = new Movie(movie);
  
	  console.log(movie);
	  console.log("IMDB URL:", customMovie.getIMDBUrl());
	} finally {
	  await client.close();
	}
  }
  run().catch(console.dir);