import express from 'express';
import dotenv from 'dotenv';
import path from 'path'
import { fileURLToPath } from 'url';

// Get current file's directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Set up EJS as the view engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.get('/greeting', (req, res) => {
    // Render the EJS template with the data
    res.render('greeting');
});

app.get('/counter', (req, res) => {
    const serverData = {
        greeting: "Hello from the server!",
        message: "This data was generated on the server and injected into the React component.",
        timestamp: new Date().toLocaleString()
    };

    // Render the EJS template with the data
    res.render('counter', { serverData });
});

app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});